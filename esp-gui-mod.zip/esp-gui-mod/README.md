# ESP GUI Mod – Fabric 1.21.1

Singleplayer ESP mit vollständiger Ingame-GUI.

## GUI öffnen
- **P** → ESP-Einstellungen öffnen
- **Right Shift** → ESP schnell an/aus

## GUI-Tabs

### General
- Master-Toggle für alles
- Liniendicke einstellen (0.5 – 5.0)
- Block-Suchradius einstellen (16 – 128 Blöcke)

### Entities
Checkboxen für: Spieler, Zombie, Skeleton, Creeper, Spider, Enderman, Witch, Blaze, Phantom, Pillager, Kuh, Schwein, Schaf, Huhn, Pferd, Wolf

### Blocks
Checkboxen für: Truhe, Ender-Truhe, Diamond-Erz, Deepslate-Diamond, Gold-Erz, Eisen-Erz, Smaragd-Erz, Ancient Debris, Spawner, Fass, Shulkerbox

### Farben
Klick auf den farbigen Kreis (●) neben dem ersten Eintrag jeder Farbgruppe → öffnet Color Picker mit R/G/B/A-Reglern und 8 Preset-Farben.

---

## Bauen (einmalig ~2 Min)

### Voraussetzungen
- **Java 21** ([adoptium.net](https://adoptium.net/))
- Gradle wird automatisch heruntergeladen

### Schritte
```bash
cd esp-gui-mod
# Windows:
gradlew.bat build
# Mac/Linux:
./gradlew build
```

Fertige Datei: `build/libs/esp-gui-mod-2.0.0.jar`

### Installation
1. [Fabric Loader 0.16.5](https://fabricmc.net/use/) für MC 1.21.1 installieren
2. [Fabric API](https://modrinth.com/mod/fabric-api) für 1.21.1 herunterladen
3. Beide `.jar` in deinen `mods/` Ordner legen
4. Nur in **Singleplayer** verwenden!

---

## Gradle Wrapper herunterladen
Falls `gradlew` fehlt:
```bash
gradle wrapper --gradle-version 8.8
```
Oder lade den Wrapper manuell von [gradle.org/releases](https://gradle.org/releases/) herunter.
