package com.espmod;

import com.espmod.config.EspConfig;
import com.espmod.gui.EspScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class EspMod implements ClientModInitializer {

    public static final Logger LOGGER = LoggerFactory.getLogger("esp-mod");
    public static final EspConfig CONFIG = new EspConfig();

    public static KeyBinding keyOpenGui;
    public static KeyBinding keyToggle;

    @Override
    public void onInitializeClient() {
        LOGGER.info("[ESP Mod] Loaded!");

        keyOpenGui = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.espmod.open_gui", GLFW.GLFW_KEY_P, "category.espmod"));

        keyToggle = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.espmod.toggle_esp", GLFW.GLFW_KEY_RIGHT_SHIFT, "category.espmod"));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null) return;

            while (keyOpenGui.wasPressed()) {
                client.setScreen(new EspScreen());
            }
            while (keyToggle.wasPressed()) {
                CONFIG.espEnabled = !CONFIG.espEnabled;
                client.player.sendMessage(
                        Text.literal("§6[ESP] §r" + (CONFIG.espEnabled ? "§aEnabled" : "§cDisabled")), true);
            }
        });
    }
}
