package com.espmod.gui;

import com.espmod.EspMod;
import com.espmod.config.EspConfig;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;

public class EspScreen extends Screen {

    // ── Layout constants ──────────────────────────────────────────────────────
    private static final int WIN_W  = 360;
    private static final int WIN_H  = 300;
    private static final int TAB_H  = 22;
    private static final int PAD    = 10;
    private static final int CB_SIZE = 12;
    private static final int ROW_H  = 18;

    // ── State ─────────────────────────────────────────────────────────────────
    private int tab = 0; // 0=General 1=Entities 2=Blocks
    private int winX, winY;

    // Color-picker state
    private float[] editingColor = null; // reference into config
    private String  editingLabel = null;
    private boolean showPicker   = false;

    // Checkbox descriptors built per-tab
    private record CB(String label, BooleanSupplier get, Runnable toggle,
                      float[] color, Runnable openColor) {}
    private final List<CB> rows = new ArrayList<>();

    // ── Constructor ───────────────────────────────────────────────────────────
    public EspScreen() {
        super(Text.literal("ESP Settings"));
    }

    // ── Init ──────────────────────────────────────────────────────────────────
    @Override
    protected void init() {
        winX = (width  - WIN_W) / 2;
        winY = (height - WIN_H) / 2;
        rebuildWidgets();
    }

    private void rebuildWidgets() {
        clearChildren();
        rows.clear();

        EspConfig c = EspMod.CONFIG;

        // Tab buttons
        String[] tabs = {"General", "Entities", "Blocks"};
        int tw = WIN_W / tabs.length;
        for (int i = 0; i < tabs.length; i++) {
            final int fi = i;
            addDrawableChild(ButtonWidget.builder(Text.literal(tabs[i]), btn -> {
                tab = fi;
                rebuildWidgets();
            }).dimensions(winX + i * tw, winY, tw, TAB_H).build());
        }

        // Close button
        addDrawableChild(ButtonWidget.builder(Text.literal("✕"), btn -> close())
                .dimensions(winX + WIN_W - 20, winY, 20, TAB_H).build());

        // Body rows depend on active tab
        switch (tab) {
            case 0 -> buildGeneralTab(c);
            case 1 -> buildEntityTab(c);
            case 2 -> buildBlockTab(c);
        }

        // Color-picker overlay (if open)
        if (showPicker && editingColor != null) {
            buildColorPicker();
        }
    }

    // ── Tab: General ──────────────────────────────────────────────────────────
    private void buildGeneralTab(EspConfig c) {
        int y = winY + TAB_H + PAD + 4;
        int x = winX + PAD;

        // Master toggle as big button
        addDrawableChild(ButtonWidget.builder(
                Text.literal("ESP: " + (c.espEnabled ? "§aON" : "§cOFF")),
                btn -> { c.espEnabled = !c.espEnabled; rebuildWidgets(); })
                .dimensions(x, y, 120, 20).build());
        y += 28;

        // Line width –  / +
        addDrawableChild(ButtonWidget.builder(Text.literal("–"), btn -> {
            c.lineWidth = Math.max(0.5f, c.lineWidth - 0.5f); rebuildWidgets();
        }).dimensions(x, y, 20, 16).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("+"), btn -> {
            c.lineWidth = Math.min(5.0f, c.lineWidth + 0.5f); rebuildWidgets();
        }).dimensions(x + 24, y, 20, 16).build());
        // label drawn in render
        y += 24;

        // Block radius –  / +
        addDrawableChild(ButtonWidget.builder(Text.literal("–"), btn -> {
            c.blockRadius = Math.max(16, c.blockRadius - 8); rebuildWidgets();
        }).dimensions(x, y, 20, 16).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("+"), btn -> {
            c.blockRadius = Math.min(128, c.blockRadius + 8); rebuildWidgets();
        }).dimensions(x + 24, y, 20, 16).build());
    }

    // ── Tab: Entities ─────────────────────────────────────────────────────────
    private void buildEntityTab(EspConfig c) {
        rows.add(new CB("Players",    () -> c.showPlayers,   () -> { c.showPlayers   = !c.showPlayers;   rebuildWidgets(); }, c.colorPlayer,  () -> openPicker(c.colorPlayer,  "Players Color")));
        rows.add(new CB("Zombie",     () -> c.showZombie,    () -> { c.showZombie    = !c.showZombie;    rebuildWidgets(); }, c.colorHostile, () -> openPicker(c.colorHostile, "Hostile Color")));
        rows.add(new CB("Skeleton",   () -> c.showSkeleton,  () -> { c.showSkeleton  = !c.showSkeleton;  rebuildWidgets(); }, c.colorHostile, null));
        rows.add(new CB("Creeper",    () -> c.showCreeper,   () -> { c.showCreeper   = !c.showCreeper;   rebuildWidgets(); }, c.colorHostile, null));
        rows.add(new CB("Spider",     () -> c.showSpider,    () -> { c.showSpider    = !c.showSpider;    rebuildWidgets(); }, c.colorHostile, null));
        rows.add(new CB("Enderman",   () -> c.showEnderman,  () -> { c.showEnderman  = !c.showEnderman;  rebuildWidgets(); }, c.colorHostile, null));
        rows.add(new CB("Witch",      () -> c.showWitch,     () -> { c.showWitch     = !c.showWitch;     rebuildWidgets(); }, c.colorHostile, null));
        rows.add(new CB("Blaze",      () -> c.showBlaze,     () -> { c.showBlaze     = !c.showBlaze;     rebuildWidgets(); }, c.colorHostile, null));
        rows.add(new CB("Phantom",    () -> c.showPhantom,   () -> { c.showPhantom   = !c.showPhantom;   rebuildWidgets(); }, c.colorHostile, null));
        rows.add(new CB("Pillager",   () -> c.showPillager,  () -> { c.showPillager  = !c.showPillager;  rebuildWidgets(); }, c.colorHostile, null));
        rows.add(new CB("Cow",        () -> c.showCow,       () -> { c.showCow       = !c.showCow;       rebuildWidgets(); }, c.colorPassive, () -> openPicker(c.colorPassive, "Passive Color")));
        rows.add(new CB("Pig",        () -> c.showPig,       () -> { c.showPig       = !c.showPig;       rebuildWidgets(); }, c.colorPassive, null));
        rows.add(new CB("Sheep",      () -> c.showSheep,     () -> { c.showSheep     = !c.showSheep;     rebuildWidgets(); }, c.colorPassive, null));
        rows.add(new CB("Chicken",    () -> c.showChicken,   () -> { c.showChicken   = !c.showChicken;   rebuildWidgets(); }, c.colorPassive, null));
        rows.add(new CB("Horse",      () -> c.showHorse,     () -> { c.showHorse     = !c.showHorse;     rebuildWidgets(); }, c.colorPassive, null));
        rows.add(new CB("Wolf",       () -> c.showWolf,      () -> { c.showWolf      = !c.showWolf;      rebuildWidgets(); }, c.colorPassive, null));
        addCheckboxWidgets();
    }

    // ── Tab: Blocks ───────────────────────────────────────────────────────────
    private void buildBlockTab(EspConfig c) {
        rows.add(new CB("Chest / Trapped",  () -> c.showChest,         () -> { c.showChest         = !c.showChest;         rebuildWidgets(); }, c.colorChest,   () -> openPicker(c.colorChest,   "Chest Color")));
        rows.add(new CB("Ender Chest",      () -> c.showEnderChest,    () -> { c.showEnderChest    = !c.showEnderChest;    rebuildWidgets(); }, c.colorChest,   null));
        rows.add(new CB("Diamond Ore",      () -> c.showDiamondOre,    () -> { c.showDiamondOre    = !c.showDiamondOre;    rebuildWidgets(); }, c.colorOre,     () -> openPicker(c.colorOre,     "Ore Color")));
        rows.add(new CB("Deepslate Diam.",  () -> c.showDeepDiamond,   () -> { c.showDeepDiamond   = !c.showDeepDiamond;   rebuildWidgets(); }, c.colorOre,     null));
        rows.add(new CB("Gold Ore",         () -> c.showGoldOre,       () -> { c.showGoldOre       = !c.showGoldOre;       rebuildWidgets(); }, c.colorOre,     null));
        rows.add(new CB("Iron Ore",         () -> c.showIronOre,       () -> { c.showIronOre       = !c.showIronOre;       rebuildWidgets(); }, c.colorOre,     null));
        rows.add(new CB("Emerald Ore",      () -> c.showEmeraldOre,    () -> { c.showEmeraldOre    = !c.showEmeraldOre;    rebuildWidgets(); }, c.colorOre,     null));
        rows.add(new CB("Ancient Debris",   () -> c.showAncientDebris, () -> { c.showAncientDebris = !c.showAncientDebris; rebuildWidgets(); }, c.colorOre,     null));
        rows.add(new CB("Spawner",          () -> c.showSpawner,       () -> { c.showSpawner       = !c.showSpawner;       rebuildWidgets(); }, c.colorSpawner, () -> openPicker(c.colorSpawner, "Spawner Color")));
        rows.add(new CB("Barrel",           () -> c.showBarrel,        () -> { c.showBarrel        = !c.showBarrel;        rebuildWidgets(); }, c.colorChest,   null));
        rows.add(new CB("Shulker Box",      () -> c.showShulkerBox,    () -> { c.showShulkerBox    = !c.showShulkerBox;    rebuildWidgets(); }, c.colorShulker, () -> openPicker(c.colorShulker, "Shulker Color")));
        addCheckboxWidgets();
    }

    // ── Helper: turn rows list into actual checkbox + color-swatch buttons ────
    private void addCheckboxWidgets() {
        int cols   = 2;
        int colW   = (WIN_W - PAD * 2) / cols;
        int startY = winY + TAB_H + PAD;

        for (int i = 0; i < rows.size(); i++) {
            CB row  = rows.get(i);
            int col = i % cols;
            int r   = i / cols;
            int x   = winX + PAD + col * colW;
            int y   = startY + r * ROW_H;

            // Checkbox toggle
            final CB frow = row;
            addDrawableChild(ButtonWidget.builder(
                    Text.literal(row.get.getAsBoolean() ? "§a✔" : "§c✘"),
                    btn -> frow.toggle.run())
                    .dimensions(x, y, CB_SIZE, CB_SIZE).build());

            // Color swatch (only if openColor != null)
            if (row.openColor() != null) {
                addDrawableChild(ButtonWidget.builder(Text.literal("●"), btn -> frow.openColor().run())
                        .dimensions(x + colW - 18, y, 14, CB_SIZE).build());
            }
        }
    }

    // ── Color Picker ──────────────────────────────────────────────────────────
    private void openPicker(float[] color, String label) {
        editingColor = color;
        editingLabel = label;
        showPicker   = true;
        rebuildWidgets();
    }

    private void buildColorPicker() {
        int pw = 180, ph = 130;
        int px = winX + (WIN_W - pw) / 2;
        int py = winY + (WIN_H - ph) / 2;
        float[] col = editingColor;

        // R –  +
        addDrawableChild(ButtonWidget.builder(Text.literal("–"), b -> { col[0] = Math.max(0, col[0] - 0.05f); rebuildWidgets(); }).dimensions(px + 40, py + 20, 16, 14).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("+"), b -> { col[0] = Math.min(1, col[0] + 0.05f); rebuildWidgets(); }).dimensions(px + 58, py + 20, 16, 14).build());
        // G –  +
        addDrawableChild(ButtonWidget.builder(Text.literal("–"), b -> { col[1] = Math.max(0, col[1] - 0.05f); rebuildWidgets(); }).dimensions(px + 40, py + 38, 16, 14).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("+"), b -> { col[1] = Math.min(1, col[1] + 0.05f); rebuildWidgets(); }).dimensions(px + 58, py + 38, 16, 14).build());
        // B –  +
        addDrawableChild(ButtonWidget.builder(Text.literal("–"), b -> { col[2] = Math.max(0, col[2] - 0.05f); rebuildWidgets(); }).dimensions(px + 40, py + 56, 16, 14).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("+"), b -> { col[2] = Math.min(1, col[2] + 0.05f); rebuildWidgets(); }).dimensions(px + 58, py + 56, 16, 14).build());
        // A –  +
        addDrawableChild(ButtonWidget.builder(Text.literal("–"), b -> { col[3] = Math.max(0, col[3] - 0.05f); rebuildWidgets(); }).dimensions(px + 40, py + 74, 16, 14).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("+"), b -> { col[3] = Math.min(1, col[3] + 0.05f); rebuildWidgets(); }).dimensions(px + 58, py + 74, 16, 14).build());

        // Preset colors
        int[][] presets = {
            {255,50,50}, {255,140,0}, {255,255,0}, {50,255,50},
            {50,180,255}, {180,50,255}, {255,255,255}, {100,100,100}
        };
        for (int i = 0; i < presets.length; i++) {
            final int[] p = presets[i];
            addDrawableChild(ButtonWidget.builder(Text.literal(""), b -> {
                col[0] = p[0]/255f; col[1] = p[1]/255f; col[2] = p[2]/255f; col[3] = 1f;
                rebuildWidgets();
            }).dimensions(px + 4 + i * 18, py + 100, 14, 14).build());
        }

        // Done
        addDrawableChild(ButtonWidget.builder(Text.literal("Done"), b -> {
            showPicker = false; editingColor = null; rebuildWidgets();
        }).dimensions(px + pw - 44, py + ph - 18, 40, 14).build());
    }

    // ── Render ────────────────────────────────────────────────────────────────
    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        // Dark background
        ctx.fillGradient(0, 0, width, height, 0xB0000000, 0xB0000000);

        // Window background
        ctx.fill(winX, winY, winX + WIN_W, winY + WIN_H, 0xE0101010);
        ctx.drawBorder(winX, winY, WIN_W, WIN_H, 0xFF444444);

        // Title
        ctx.drawCenteredTextWithShadow(textRenderer, "§bESP Settings", winX + WIN_W / 2, winY + 4, 0xFFFFFF);

        super.render(ctx, mouseX, mouseY, delta);

        EspConfig c = EspMod.CONFIG;

        // Per-tab extra labels
        if (tab == 0) {
            int lx = winX + PAD + 50;
            int y  = winY + TAB_H + PAD + 4;
            ctx.drawTextWithShadow(textRenderer, "§7Master Toggle", lx, y + 6, 0xAAAAAA);
            ctx.drawTextWithShadow(textRenderer,
                    "§7Line Width: §f" + String.format("%.1f", c.lineWidth), lx, y + 34, 0xAAAAAA);
            ctx.drawTextWithShadow(textRenderer,
                    "§7Block Radius: §f" + c.blockRadius, lx, y + 58, 0xAAAAAA);
        }

        // Checkbox row labels + color swatches
        if (tab == 1 || tab == 2) {
            int cols   = 2;
            int colW   = (WIN_W - PAD * 2) / cols;
            int startY = winY + TAB_H + PAD;

            for (int i = 0; i < rows.size(); i++) {
                CB row  = rows.get(i);
                int col = i % cols;
                int r   = i / cols;
                int x   = winX + PAD + col * colW;
                int y   = startY + r * ROW_H;

                // Label next to checkbox
                ctx.drawTextWithShadow(textRenderer, row.label(), x + CB_SIZE + 3, y + 2, 0xDDDDDD);

                // Color swatch preview
                if (row.color() != null) {
                    float[] col2 = row.color();
                    int argb = (int)(col2[3]*255) << 24 | (int)(col2[0]*255) << 16
                             | (int)(col2[1]*255) << 8  | (int)(col2[2]*255);
                    ctx.fill(x + colW - 18, y, x + colW - 6, y + CB_SIZE, argb);
                    ctx.drawBorder(x + colW - 18, y, 12, CB_SIZE, 0xFF888888);
                }
            }
        }

        // Color picker overlay
        if (showPicker && editingColor != null) {
            int pw = 180, ph = 130;
            int px = winX + (WIN_W - pw) / 2;
            int py = winY + (WIN_H - ph) / 2;
            ctx.fill(px, py, px + pw, py + ph, 0xF0202020);
            ctx.drawBorder(px, py, pw, ph, 0xFF888888);
            ctx.drawCenteredTextWithShadow(textRenderer, "§e" + editingLabel, px + pw / 2, py + 6, 0xFFFFFF);

            float[] col = editingColor;
            ctx.drawTextWithShadow(textRenderer, String.format("§cR: %.2f", col[0]), px + 4, py + 23, 0xFFFFFF);
            ctx.drawTextWithShadow(textRenderer, String.format("§aG: %.2f", col[1]), px + 4, py + 41, 0xFFFFFF);
            ctx.drawTextWithShadow(textRenderer, String.format("§9B: %.2f", col[2]), px + 4, py + 59, 0xFFFFFF);
            ctx.drawTextWithShadow(textRenderer, String.format("§7A: %.2f", col[3]), px + 4, py + 77, 0xFFFFFF);

            // Live preview swatch
            int argb = (int)(col[3]*255) << 24 | (int)(col[0]*255) << 16
                     | (int)(col[1]*255) << 8  | (int)(col[2]*255);
            ctx.fill(px + pw - 30, py + 20, px + pw - 6, py + 90, argb);
            ctx.drawBorder(px + pw - 30, py + 20, 24, 70, 0xFF888888);

            // Preset swatches
            int[][] presets = {
                {255,50,50},{255,140,0},{255,255,0},{50,255,50},
                {50,180,255},{180,50,255},{255,255,255},{100,100,100}
            };
            for (int i = 0; i < presets.length; i++) {
                int c2 = 0xFF000000 | (presets[i][0] << 16) | (presets[i][1] << 8) | presets[i][2];
                ctx.fill(px + 4 + i * 18, py + 100, px + 18 + i * 18, py + 114, c2);
                ctx.drawBorder(px + 4 + i * 18, py + 100, 14, 14, 0xFF666666);
            }
        }
    }

    @Override
    public boolean shouldPause() { return false; }
}
