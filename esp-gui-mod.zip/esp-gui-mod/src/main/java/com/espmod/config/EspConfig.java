package com.espmod.config;

import net.minecraft.block.Block;
import net.minecraft.block.Blocks;

import java.util.*;

public class EspConfig {

    // ── Global ────────────────────────────────────────────────────────────────
    public boolean espEnabled = true;

    // ── Entity toggles ────────────────────────────────────────────────────────
    public boolean showPlayers       = true;
    public boolean showZombie        = true;
    public boolean showSkeleton      = true;
    public boolean showCreeper       = true;
    public boolean showSpider        = true;
    public boolean showEnderman      = true;
    public boolean showWitch         = true;
    public boolean showBlaze         = true;
    public boolean showPhantom       = true;
    public boolean showPillager      = true;
    public boolean showCow           = false;
    public boolean showPig           = false;
    public boolean showSheep         = false;
    public boolean showChicken       = false;
    public boolean showHorse         = false;
    public boolean showWolf          = false;

    // ── Entity colors (RGBA 0–1) ──────────────────────────────────────────────
    public float[] colorPlayer    = {1.0f, 0.2f, 0.2f, 1.0f};
    public float[] colorHostile   = {1.0f, 0.5f, 0.0f, 1.0f};
    public float[] colorPassive   = {0.2f, 1.0f, 0.2f, 1.0f};

    // ── Block toggles ─────────────────────────────────────────────────────────
    public boolean showChest          = true;
    public boolean showEnderChest     = true;
    public boolean showDiamondOre     = true;
    public boolean showDeepDiamond    = true;
    public boolean showGoldOre        = false;
    public boolean showIronOre        = false;
    public boolean showEmeraldOre     = true;
    public boolean showAncientDebris  = true;
    public boolean showSpawner        = true;
    public boolean showBarrel         = false;
    public boolean showShulkerBox     = true;

    // ── Block colors ──────────────────────────────────────────────────────────
    public float[] colorChest       = {1.0f, 1.0f, 0.0f, 1.0f};
    public float[] colorOre         = {0.2f, 0.6f, 1.0f, 1.0f};
    public float[] colorSpawner     = {0.8f, 0.0f, 1.0f, 1.0f};
    public float[] colorShulker     = {0.9f, 0.4f, 0.9f, 1.0f};

    // ── Render settings ───────────────────────────────────────────────────────
    public int   blockRadius = 48;
    public float lineWidth   = 1.5f;

    // ── Helpers ───────────────────────────────────────────────────────────────
    /** Returns the set of blocks that should be highlighted right now. */
    public Set<Block> activeBlocks() {
        Set<Block> set = new HashSet<>();
        if (showChest)         { set.add(Blocks.CHEST); set.add(Blocks.TRAPPED_CHEST); }
        if (showEnderChest)    set.add(Blocks.ENDER_CHEST);
        if (showDiamondOre)    set.add(Blocks.DIAMOND_ORE);
        if (showDeepDiamond)   set.add(Blocks.DEEPSLATE_DIAMOND_ORE);
        if (showGoldOre)       { set.add(Blocks.GOLD_ORE); set.add(Blocks.DEEPSLATE_GOLD_ORE); }
        if (showIronOre)       { set.add(Blocks.IRON_ORE); set.add(Blocks.DEEPSLATE_IRON_ORE); }
        if (showEmeraldOre)    { set.add(Blocks.EMERALD_ORE); set.add(Blocks.DEEPSLATE_EMERALD_ORE); }
        if (showAncientDebris) set.add(Blocks.ANCIENT_DEBRIS);
        if (showSpawner)       set.add(Blocks.SPAWNER);
        if (showBarrel)        set.add(Blocks.BARREL);
        if (showShulkerBox)    addAllShulkers(set);
        return set;
    }

    private void addAllShulkers(Set<Block> set) {
        set.add(Blocks.SHULKER_BOX);
        set.add(Blocks.WHITE_SHULKER_BOX);   set.add(Blocks.ORANGE_SHULKER_BOX);
        set.add(Blocks.MAGENTA_SHULKER_BOX); set.add(Blocks.LIGHT_BLUE_SHULKER_BOX);
        set.add(Blocks.YELLOW_SHULKER_BOX);  set.add(Blocks.LIME_SHULKER_BOX);
        set.add(Blocks.PINK_SHULKER_BOX);    set.add(Blocks.GRAY_SHULKER_BOX);
        set.add(Blocks.LIGHT_GRAY_SHULKER_BOX); set.add(Blocks.CYAN_SHULKER_BOX);
        set.add(Blocks.PURPLE_SHULKER_BOX);  set.add(Blocks.BLUE_SHULKER_BOX);
        set.add(Blocks.BROWN_SHULKER_BOX);   set.add(Blocks.GREEN_SHULKER_BOX);
        set.add(Blocks.RED_SHULKER_BOX);     set.add(Blocks.BLACK_SHULKER_BOX);
    }
}
