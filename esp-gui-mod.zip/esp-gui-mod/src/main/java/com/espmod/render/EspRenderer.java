package com.espmod.render;

import com.espmod.EspMod;
import com.espmod.config.EspConfig;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.*;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.mob.*;
import net.minecraft.entity.passive.*;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

import java.util.Set;

public class EspRenderer {

    public static void render(MatrixStack matrices, float tickDelta) {
        EspConfig cfg = EspMod.CONFIG;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (!cfg.espEnabled || mc.world == null || mc.player == null) return;

        Vec3d cam = mc.gameRenderer.getCamera().getPos();

        RenderSystem.enableDepthTest();
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();
        RenderSystem.depthMask(false);
        RenderSystem.lineWidth(cfg.lineWidth);

        Tessellator tess   = Tessellator.getInstance();
        BufferBuilder buf  = tess.begin(VertexFormat.DrawMode.DEBUG_LINES, VertexFormats.POSITION_COLOR);

        matrices.push();
        matrices.translate(-cam.x, -cam.y, -cam.z);
        Matrix4f mat = matrices.peek().getPositionMatrix();

        // ── Entity ESP ────────────────────────────────────────────────────────
        for (Entity e : mc.world.getEntities()) {
            if (e == mc.player) continue;
            float[] color = entityColor(e, cfg);
            if (color == null) continue;
            drawBox(buf, mat, e.getBoundingBox(), color);
        }

        // ── Block ESP ─────────────────────────────────────────────────────────
        Set<Block> tracked = cfg.activeBlocks();
        if (!tracked.isEmpty()) {
            BlockPos origin = mc.player.getBlockPos();
            int r = cfg.blockRadius;
            int minY = mc.world.getBottomY();
            int maxY = mc.world.getTopY();

            for (int x = -r; x <= r; x++) {
                for (int z = -r; z <= r; z++) {
                    for (int y = minY; y < maxY; y++) {
                        BlockPos pos   = origin.add(x, y - origin.getY(), z);
                        Block    block = mc.world.getBlockState(pos).getBlock();
                        if (!tracked.contains(block)) continue;
                        float[] color = blockColor(block, cfg);
                        if (color == null) continue;
                        drawBox(buf, mat, new Box(pos), color);
                    }
                }
            }
        }

        matrices.pop();

        BuiltBuffer built = buf.endNullable();
        if (built != null) {
            RenderSystem.setShader(GameRenderer::getPositionColorProgram);
            BufferRenderer.drawWithGlobalProgram(built);
        }

        RenderSystem.depthMask(true);
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private static float[] entityColor(Entity e, EspConfig cfg) {
        if (e instanceof PlayerEntity  && cfg.showPlayers)  return cfg.colorPlayer;
        if (e instanceof ZombieEntity  && cfg.showZombie)   return cfg.colorHostile;
        if (e instanceof SkeletonEntity&& cfg.showSkeleton) return cfg.colorHostile;
        if (e instanceof CreeperEntity && cfg.showCreeper)  return cfg.colorHostile;
        if (e instanceof SpiderEntity  && cfg.showSpider)   return cfg.colorHostile;
        if (e instanceof EndermanEntity&& cfg.showEnderman) return cfg.colorHostile;
        if (e instanceof WitchEntity   && cfg.showWitch)    return cfg.colorHostile;
        if (e instanceof BlazeEntity   && cfg.showBlaze)    return cfg.colorHostile;
        if (e instanceof PhantomEntity && cfg.showPhantom)  return cfg.colorHostile;
        if (e instanceof PillagerEntity&& cfg.showPillager) return cfg.colorHostile;
        if (e instanceof CowEntity     && cfg.showCow)      return cfg.colorPassive;
        if (e instanceof PigEntity     && cfg.showPig)      return cfg.colorPassive;
        if (e instanceof SheepEntity   && cfg.showSheep)    return cfg.colorPassive;
        if (e instanceof ChickenEntity && cfg.showChicken)  return cfg.colorPassive;
        if (e instanceof HorseEntity   && cfg.showHorse)    return cfg.colorPassive;
        if (e instanceof WolfEntity    && cfg.showWolf)     return cfg.colorPassive;
        return null;
    }

    private static float[] blockColor(Block b, EspConfig cfg) {
        if (b == Blocks.SPAWNER) return cfg.colorSpawner;
        if (b == Blocks.CHEST || b == Blocks.TRAPPED_CHEST ||
            b == Blocks.ENDER_CHEST || b == Blocks.BARREL)  return cfg.colorChest;
        if (isShulker(b))                                    return cfg.colorShulker;
        return cfg.colorOre; // default for ores / debris
    }

    private static boolean isShulker(Block b) {
        return b == Blocks.SHULKER_BOX || b == Blocks.WHITE_SHULKER_BOX ||
               b == Blocks.ORANGE_SHULKER_BOX || b == Blocks.MAGENTA_SHULKER_BOX ||
               b == Blocks.LIGHT_BLUE_SHULKER_BOX || b == Blocks.YELLOW_SHULKER_BOX ||
               b == Blocks.LIME_SHULKER_BOX || b == Blocks.PINK_SHULKER_BOX ||
               b == Blocks.GRAY_SHULKER_BOX || b == Blocks.LIGHT_GRAY_SHULKER_BOX ||
               b == Blocks.CYAN_SHULKER_BOX || b == Blocks.PURPLE_SHULKER_BOX ||
               b == Blocks.BLUE_SHULKER_BOX || b == Blocks.BROWN_SHULKER_BOX ||
               b == Blocks.GREEN_SHULKER_BOX || b == Blocks.RED_SHULKER_BOX ||
               b == Blocks.BLACK_SHULKER_BOX;
    }

    private static void drawBox(BufferBuilder buf, Matrix4f mat, Box box, float[] c) {
        float x1=(float)box.minX, y1=(float)box.minY, z1=(float)box.minZ;
        float x2=(float)box.maxX, y2=(float)box.maxY, z2=(float)box.maxZ;
        float r=c[0], g=c[1], b=c[2], a=c[3];
        // bottom
        line(buf,mat, x1,y1,z1, x2,y1,z1,r,g,b,a); line(buf,mat, x2,y1,z1, x2,y1,z2,r,g,b,a);
        line(buf,mat, x2,y1,z2, x1,y1,z2,r,g,b,a); line(buf,mat, x1,y1,z2, x1,y1,z1,r,g,b,a);
        // top
        line(buf,mat, x1,y2,z1, x2,y2,z1,r,g,b,a); line(buf,mat, x2,y2,z1, x2,y2,z2,r,g,b,a);
        line(buf,mat, x2,y2,z2, x1,y2,z2,r,g,b,a); line(buf,mat, x1,y2,z2, x1,y2,z1,r,g,b,a);
        // verticals
        line(buf,mat, x1,y1,z1, x1,y2,z1,r,g,b,a); line(buf,mat, x2,y1,z1, x2,y2,z1,r,g,b,a);
        line(buf,mat, x2,y1,z2, x2,y2,z2,r,g,b,a); line(buf,mat, x1,y1,z2, x1,y2,z2,r,g,b,a);
    }

    private static void line(BufferBuilder buf, Matrix4f mat,
            float x1,float y1,float z1, float x2,float y2,float z2,
            float r,float g,float b,float a) {
        buf.vertex(mat,x1,y1,z1).color(r,g,b,a);
        buf.vertex(mat,x2,y2,z2).color(r,g,b,a);
    }
}
